// if (
//   localStorage.getItem('dark-mode') === 'true' ||
//   (localStorage.getItem('dark-mode') === null &&
//    window.matchMedia('(prefers-color-scheme: dark)').matches)
// ) {
//   document.body.classList.add('dark-mode');
// }